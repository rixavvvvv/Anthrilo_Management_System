/**
 * Generic WebSocket hook for real-time updates
 * Supports multiple event types: sales, inventory, orders, production, all
 */
import { useEffect, useRef, useState } from 'react';

interface WebSocketMessage {
  type: string;
  data?: any;
  message?: string;
  timestamp?: string;
}

interface UseWebSocketOptions {
  eventType?: 'sales' | 'inventory' | 'orders' | 'production' | 'all';
  onMessage?: (message: WebSocketMessage) => void;
  onConnect?: () => void;
  onDisconnect?: () => void;
  reconnectInterval?: number;
  maxReconnectAttempts?: number;
}

export function useWebSocketGeneric(options: UseWebSocketOptions = {}) {
  const {
    eventType = 'all',
    onMessage,
    onConnect,
    onDisconnect,
    reconnectInterval = 3000,
    maxReconnectAttempts = 10,
  } = options;

  const [isConnected, setIsConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<WebSocketMessage | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectAttemptsRef = useRef(0);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();

  const connect = () => {
    try {
      // Close existing connection if any
      if (wsRef.current) {
        wsRef.current.close();
      }

      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//localhost:8002/api/v1/integrations/ws/${eventType}`;
      
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        console.log(`[WebSocket] Connected to ${eventType} events`);
        setIsConnected(true);
        setError(null);
        reconnectAttemptsRef.current = 0;
        
        // Send subscribe message
        ws.send(JSON.stringify({ action: 'subscribe' }));
        
        if (onConnect) {
          onConnect();
        }
      };

      ws.onmessage = (event) => {
        try {
          const message: WebSocketMessage = JSON.parse(event.data);
          setLastMessage(message);
          
          if (onMessage) {
            onMessage(message);
          }
        } catch (err) {
          console.error('[WebSocket] Error parsing message:', err);
        }
      };

      ws.onerror = (event) => {
        console.error('[WebSocket] Error:', event);
        setError('WebSocket connection error');
      };

      ws.onclose = () => {
        console.log(`[WebSocket] Disconnected from ${eventType}`);
        setIsConnected(false);
        
        if (onDisconnect) {
          onDisconnect();
        }

        // Attempt to reconnect
        if (reconnectAttemptsRef.current < maxReconnectAttempts) {
          reconnectAttemptsRef.current++;
          console.log(
            `[WebSocket] Reconnecting... (attempt ${reconnectAttemptsRef.current}/${maxReconnectAttempts})`
          );
          reconnectTimeoutRef.current = setTimeout(connect, reconnectInterval);
        } else {
          setError(`Failed to connect after ${maxReconnectAttempts} attempts`);
          console.error(`[WebSocket] Max reconnection attempts reached`);
        }
      };
    } catch (err) {
      console.error('[WebSocket] Connection error:', err);
      setError('Failed to establish WebSocket connection');
    }
  };

  useEffect(() => {
    connect();

    return () => {
      // Cleanup on unmount
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [eventType]); // Reconnect if eventType changes

  const sendMessage = (message: any) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(message));
    } else {
      console.warn('[WebSocket] Cannot send message - not connected');
    }
  };

  const disconnect = () => {
    if (wsRef.current) {
      wsRef.current.close();
    }
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }
  };

  return {
    isConnected,
    lastMessage,
    error,
    sendMessage,
    disconnect,
    reconnect: connect,
  };
}

// Specific hooks for different event types

export function useInventoryWebSocket(
  onUpdate?: (data: any) => void
) {
  return useWebSocketGeneric({
    eventType: 'inventory',
    onMessage: (message) => {
      if (message.type === 'inventory_update' && onUpdate) {
        onUpdate(message.data);
      }
    },
  });
}

export function useOrdersWebSocket(
  onUpdate?: (data: any) => void
) {
  return useWebSocketGeneric({
    eventType: 'orders',
    onMessage: (message) => {
      if (message.type === 'order_update' && onUpdate) {
        onUpdate(message.data);
      }
    },
  });
}

export function useProductionWebSocket(
  onUpdate?: (data: any) => void
) {
  return useWebSocketGeneric({
    eventType: 'production',
    onMessage: (message) => {
      if (message.type === 'production_update' && onUpdate) {
        onUpdate(message.data);
      }
    },
  });
}
