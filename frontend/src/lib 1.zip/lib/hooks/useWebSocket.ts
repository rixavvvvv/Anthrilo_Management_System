'use client'

import { useEffect, useRef, useCallback, useState } from 'react'
import { useQueryClient } from '@tanstack/react-query'

const WS_URL = process.env.NEXT_PUBLIC_WS_URL || 'ws://localhost:8002/api/v1/integrations/ws/sales'
const RECONNECT_DELAY = 3000
const MAX_RECONNECT_ATTEMPTS = 10

interface WebSocketMessage {
  type: string
  data?: any
  message?: string
}

/**
 * WebSocket hook for real-time dashboard updates.
 * Automatically reconnects and updates React Query cache when new data arrives.
 * 
 * Usage:
 *   const { isConnected, lastUpdate } = useWebSocket()
 * 
 * When the server pushes today_sales data, the React Query cache
 * for 'unicommerce-today' is automatically updated — no polling needed.
 */
export function useWebSocket() {
  const wsRef = useRef<WebSocket | null>(null)
  const reconnectAttemptsRef = useRef(0)
  const reconnectTimerRef = useRef<ReturnType<typeof setTimeout>>()
  const queryClient = useQueryClient()
  const [isConnected, setIsConnected] = useState(false)
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null)

  const connect = useCallback(() => {
    // Don't connect during SSR
    if (typeof window === 'undefined') return
    
    // Clean up existing connection
    if (wsRef.current?.readyState === WebSocket.OPEN) return

    // Stop trying after max attempts
    if (reconnectAttemptsRef.current >= MAX_RECONNECT_ATTEMPTS) {
      if (reconnectAttemptsRef.current === MAX_RECONNECT_ATTEMPTS) {
        console.warn('WebSocket: Max reconnection attempts reached. Server may be offline.')
        reconnectAttemptsRef.current++ // Increment to prevent repeated warnings
      }
      return
    }

    try {
      const ws = new WebSocket(WS_URL)
      wsRef.current = ws

      ws.onopen = () => {
        setIsConnected(true)
        reconnectAttemptsRef.current = 0
        console.log('WebSocket: Connected to sales feed')
        // Subscribe to live feed
        ws.send(JSON.stringify({ action: 'subscribe' }))
      }

      ws.onmessage = (event) => {
        try {
          const msg: WebSocketMessage = JSON.parse(event.data)

          if (msg.type === 'today_sales' && msg.data) {
            // Update React Query cache directly — no refetch needed
            queryClient.setQueryData(['unicommerce-today'], msg.data)
            setLastUpdate(new Date())
          }
        } catch {
          // Ignore malformed messages
        }
      }

      ws.onclose = () => {
        setIsConnected(false)
        wsRef.current = null

        // Auto-reconnect with backoff
        if (reconnectAttemptsRef.current < MAX_RECONNECT_ATTEMPTS) {
          const delay = RECONNECT_DELAY * Math.min(reconnectAttemptsRef.current + 1, 5)
          
          if (reconnectAttemptsRef.current === 0) {
            console.log('WebSocket: Connection closed. Will retry...')
          }
          
          reconnectTimerRef.current = setTimeout(() => {
            reconnectAttemptsRef.current++
            connect()
          }, delay)
        } else {
          console.warn('WebSocket: Unable to connect. Please ensure backend is running on port 8002.')
        }
      }

      ws.onerror = (error) => {
        // Only log first few errors to avoid console spam
        if (reconnectAttemptsRef.current < 3) {
          console.error('WebSocket: Connection error', error)
        }
        ws.close()
      }
    } catch (error) {
      // Silently fail during SSR or if WebSocket not available
      if (reconnectAttemptsRef.current < 3) {
        console.error('WebSocket: Failed to create connection', error)
      }
    }
  }, [queryClient])

  useEffect(() => {
    connect()

    return () => {
      if (reconnectTimerRef.current) {
        clearTimeout(reconnectTimerRef.current)
      }
      if (wsRef.current) {
        wsRef.current.close()
      }
    }
  }, [connect])

  const requestRefresh = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ action: 'refresh' }))
    }
  }, [])

  return { isConnected, lastUpdate, requestRefresh }
}
