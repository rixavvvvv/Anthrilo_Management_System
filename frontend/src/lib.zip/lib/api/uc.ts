import { unicommerceApi } from './index';
import { apiClient } from '@/lib/api-client';

/**
 * Legacy exports for backward compatibility
 * All functionality is now in unicommerceApi in index.ts
 */

// Sales-related APIs
export const ucSales = {
    getToday: unicommerceApi.getToday,
    getYesterday: unicommerceApi.getYesterday,
    getLast7Days: unicommerceApi.getLast7Days,
    getLast30Days: unicommerceApi.getLast30Days,
    getLast24Hours: unicommerceApi.getLast24Hours,
    getTodayOrders: unicommerceApi.getTodayOrders,
    getYesterdayOrders: unicommerceApi.getYesterdayOrders,
    getLast7DaysOrders: unicommerceApi.getLast7DaysOrders,
    getLast30DaysOrders: unicommerceApi.getLast30DaysOrders,
    getCustomOrders: unicommerceApi.getCustomOrders,
    getSalesReport: unicommerceApi.getSalesReport,
    getDailySalesReport: unicommerceApi.getDailySalesReport,
    getDailyReturnReport: unicommerceApi.getDailyReturnReport,
    getChannelRevenue: unicommerceApi.getChannelRevenue,
    validateRevenue: unicommerceApi.validateRevenue,
    getBestSkusMonthly: unicommerceApi.getBestSkusMonthly,
    getCodVsPrepaid: unicommerceApi.getCodVsPrepaid,

    // Additional functions used by legacy pages
    getOrders: async (params: { period: string; page: number; page_size: number; from_date?: string; to_date?: string }) => {
        const { period, page, page_size, from_date, to_date } = params;

        // Map period to the appropriate endpoint
        if (period === 'custom' && from_date && to_date) {
            return unicommerceApi.getCustomOrders({ from_date, to_date, page, page_size });
        } else if (period === 'today') {
            return unicommerceApi.getTodayOrders(page, page_size);
        } else if (period === 'yesterday') {
            return unicommerceApi.getYesterdayOrders(page, page_size);
        } else if (period === 'last_7_days') {
            return unicommerceApi.getLast7DaysOrders(page, page_size);
        } else if (period === 'last_30_days') {
            return unicommerceApi.getLast30DaysOrders(page, page_size);
        } else {
            return unicommerceApi.getTodayOrders(page, page_size);
        }
    },

    getSalesBySku: (params: { period: string; from_date?: string; to_date?: string }) =>
        apiClient.get('/integrations/unicommerce/sales-by-sku', { params }),
};

// Catalog-related APIs
export const ucCatalog = {
    searchItems: (params: {
        displayStart: number;
        displayLength: number;
        getInventorySnapshot?: boolean;
        keyword?: string;
    }) => {
        // Transform params to Unicommerce format
        const payload: any = {
            getInventorySnapshot: params.getInventorySnapshot ?? false,
            searchOptions: {
                displayStart: params.displayStart,
                displayLength: params.displayLength,
            },
        };

        if (params.keyword) {
            payload.keyword = params.keyword;
        }

        return apiClient.post('/uc/catalog/item/search', payload);
    },
};
