import { useQuery } from "@tanstack/react-query";
import { apiClient } from "../api-client";

export function useDailySales(date: string) {
    return useQuery({
        queryKey: ["dailySales", date],
        queryFn: async () => {
            const response = await apiClient.get(`/reports/sales/daily/${date}`);
            return response.data;
        },
        enabled: !!date, // Only fetch if date is provided
        staleTime: 5 * 60 * 1000, // 5 minutes
    });
}